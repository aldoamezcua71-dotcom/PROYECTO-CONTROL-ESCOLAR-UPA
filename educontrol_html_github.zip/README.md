# EDUCONTROL - Versión HTML

## Archivos
- `index.html`: estructura de la página.
- `estilos.css`: diseño visual y adaptación a celulares.
- `app.js`: inicio de sesión, roles, formularios y calificaciones.

## Cómo abrir
Descarga la carpeta y abre `index.html` en tu navegador. No requiere instalar programas.

## Cuenta de demostración
- Usuario: `admin`
- Contraseña: `admin123`

Desde el panel de administrador puedes crear cuentas de profesores y alumnos. El profesor puede registrar calificaciones. El alumno solo ve las calificaciones asociadas a su cuenta.

## GitHub Pages
Sube los tres archivos a un repositorio y activa GitHub Pages en Settings > Pages > Deploy from a branch > main > /(root).

## Aviso importante
Esta versión guarda los datos en `localStorage` del navegador y es únicamente una demostración escolar. No proporciona seguridad real: los datos pueden modificarse desde el navegador y las contraseñas no están protegidas. No almacenes datos personales ni calificaciones reales. Para uso real, utiliza un backend con autenticación, permisos y base de datos segura.
